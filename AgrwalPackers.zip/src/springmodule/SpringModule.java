package springmodule;

import java.util.Scanner;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.context.ApplicationContext;
import spring.dao.LiveProject;
import spring.dto.ChangeQuotationReq;
import spring.dto.MarketUser;
import spring.dto.PasswordUpdateReq;
import spring.dto.Quotation;

public class SpringModule {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ApplicationContext context = new ClassPathXmlApplicationContext("SpringXMLConfig.xml");
        LiveProject dao = (LiveProject) context.getBean("techno");
        int ch = 0;

        do {
            byte ref = dao.checkLogin();

            switch (ref) {

                case 1:
                    do {
                        System.out.println("____Index_____");
                        System.out.println("1.Add Quotation:");
                        System.out.println("2.Send Request to Update Quotation:");
                        System.out.println("3.Send Request to Update Password:");
                        System.out.println("4.Exit:");
                        System.out.println("Enter your choice:");
                        int choice = sc.nextInt();
                        switch (choice) {
                            case 1:

                                System.out.println("Enter Quotation Detail:");
                                System.out.println("Enter Quotation Id:");
                                String quoId = sc.next();
                                System.out.println("Enter Client Name");
                                String clientName = sc.next();
                                System.out.println("Enter Client Address");
                                String cAddress = sc.next();
                                System.out.println("Enter Contact");
                                String contact = sc.next();
                                System.out.println("Enter Shiftig Address");
                                String sAddress = sc.next();
                                System.out.println("Enter Quotation Detail");
                                String quoDetail = sc.next();
                                System.out.println("Enter Date");
                                String date = sc.next();
                                Quotation quotation = new Quotation(quoId, clientName, cAddress, contact, sAddress, quoDetail, date);
                                dao.insertQuatation(quotation);
                                break;
                            case 2:
                                System.out.println("Enter Detail to Send Request to UpdateQuotation ");
                                System.out.println("EnterQuotaion Id:");
                                String id = sc.next();
                                System.out.println("Enter Reason to Update Quotation:");
                                String reason = sc.next();
                                System.out.println("Enter Field to change in Quotation:");
                                String field = sc.next();
                                System.out.println("Enter Detail to Change:");
                                String detail = sc.next();

                                ChangeQuotationReq request = new ChangeQuotationReq(id, reason, field, detail);
                                dao.insertChangeQuotation(request);
                                break;
                            case 3:
                                System.out.println("Enter Detail to Send Request to UpdatePassword ");
                                System.out.println("Enter User Id:");
                                String id1 = sc.next();
                                System.out.println("Enter old Password:");
                                String oPass = sc.next();
                                System.out.println("Enter new Password:");
                                String nPass = sc.next();
                                System.out.println("Enter Reason to update password:");
                                String reson = sc.next();
                                PasswordUpdateReq request1 = new PasswordUpdateReq(id1, oPass, nPass, reson);
                                dao.insertPasswordUpdate(request1);
                                break;
                            case 4:
                                System.exit(0);
                                break;
                        }
                        System.out.println("Press 1 to continue...");
                        ch = sc.nextInt();
                    } while (ch == 1);
                    break;
                case 2:
                    do {
                        System.out.println("____Index_____");
                        System.out.println("1.View Qutation");
                        System.out.println("2.Update Incentive:");
                        System.out.println("3.Add Market User Salary:");
                        System.out.println("4.Update Qutation:");
                        System.out.println("5.Update Password:");
                        System.out.println("6.View Quotation Update Request:");
                        System.out.println("7.View Password Update Request:");
                        System.out.println("8.Exit:");
                        System.out.println("Enter your choice:");
                        int choice1 = sc.nextInt();
                        switch (choice1) {
                            case 1:
                                dao.showQuotation();
                                break;
                            case 2:
                                System.out.println("Enter Employee Id to update incentive:");
                                String empId = sc.next();
                                dao.updateIncentive(empId);
                                break;
                            case 3:
                                System.out.println("Enter Employee id:");
                                String emId = sc.next();
                                System.out.println("Enter Basic Salary:");
                                int bSalary = sc.nextInt();
                                System.out.println("Enter Incentive:");
                                int incentive = sc.nextInt();
                                System.out.println("Enter Deduct Amount:");
                                int ded = sc.nextInt();
                                System.out.println("Enter Total Salary:");
                                int totSalary = sc.nextInt();
                                MarketUser mUser = new MarketUser(emId, bSalary, incentive, totSalary, ded);
                                dao.insertSalary(mUser);
                                break;
                            case 4:
                                System.out.println("Enter Quotation id to update");
                                String qId = sc.next();
                                dao.updateQuotation(qId);
                                break;
                            case 5:
                                System.out.println("Enter Market user id");
                                String userId = sc.next();
                                System.out.println("Enter Old Password");
                                String oldPass = sc.next();
                                dao.updatePassword(userId, oldPass);
                                break;
                            case 6:
                                dao.showQuotationUpdateReq();
                                break;
                            case 7:
                                dao.showPasswordUpdateReq();
                                break;
                            case 8:
                                System.exit(0);
                                break;
                        }
                        System.out.println("Press 1 to continue...");
                        ch = sc.nextInt();
                    } while (ch == 1);
                    break;
                    
                default:
                    System.out.println("Invalid id/Password/Post");
                    break;

            }
            System.out.println("Enter 1 to continue");
            ch = sc.nextInt();
        } while (ch == 1);

    }
}
//           if(ref==1){                    
//         System.out.println("HEllo Market user");
//        }
//        else if(ref==2){
//          System.out.println("hiiii accoutant");  
//        }
//        else{
//            System.out.println("Invalid id/Password/Post");
//        }
