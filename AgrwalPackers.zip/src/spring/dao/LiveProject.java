package spring.dao;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.orm.hibernate3.HibernateTemplate;
import spring.dto.ChangeQuotationReq;
import spring.dto.MarketUser;
import spring.dto.PasswordUpdateReq;
import spring.dto.Quotation;
import spring.dto.User;

public class LiveProject {

    Scanner sc = new Scanner(System.in);
    private HibernateTemplate template;

    public HibernateTemplate getTemplate() {
        return template;
    }

    public void setTemplate(HibernateTemplate template) {
        this.template = template;
    }


    
    public byte checkLogin() {

        System.out.println("Enter User Id:");
        String id = sc.next();
        System.out.println("Enter Password:");
        String pass = sc.next();
        System.out.println("Enter Post:");
        String post = sc.next();
        List<User> ct = template.find("from User where userId=? and password=? and post=?", id, pass,post);
        if (ct.isEmpty()) {
            return 0;
        } else {
            if (post.equalsIgnoreCase("MarketUser")) {
                return 1;
            } 
            else if (post.equalsIgnoreCase("Accoutant")) {
                return 2;
            }
        }
        return 3;
    }
    
    public void insertQuatation(Quotation ref){
        template.execute(new HibernateCallback<Object>() {
            @Override
            public Object doInHibernate(Session session) throws HibernateException, SQLException {
               session.save(ref);
                System.out.println("Record inserted");
                return null;
                      }
        });
       }
    
    public void insertChangeQuotation(ChangeQuotationReq ref){
        
        template.execute(new HibernateCallback<Object>() {
            @Override
            public Object doInHibernate(Session session) throws HibernateException, SQLException {
                session.save(ref);
                System.out.println("Request Sent..!!");
                return null;
            }
        });
    }
    public void insertPasswordUpdate(PasswordUpdateReq ref){
        
        template.execute(new HibernateCallback<Object>() {
            @Override
            public Object doInHibernate(Session session) throws HibernateException, SQLException {
                session.save(ref);
                System.out.println("Request Sent..!!");
                return null;
                 }
        });
    }
            
        public void showQuotation()
        {
        
        template.execute(new HibernateCallback<Object>() {
            @Override
            public Object doInHibernate(Session session) throws HibernateException, SQLException {
                Criteria ct=session.createCriteria(Quotation.class);
                List<Quotation> data =ct.list();
                for(Quotation qt:data){
                    System.out.println(qt.getqId()+" "+qt.getcName()+" "+qt.getAddress()+" "+qt.getContact()+" "+qt.getShiftAddress()+" "+qt.getqDetail()+" "+qt.getDate());
                }
                  return null;
                 }
        });
    }
        
        public void showQuotationUpdateReq(){
        
        template.execute(new HibernateCallback<Object>() {
            @Override
            public Object doInHibernate(Session session) throws HibernateException, SQLException {
                Criteria ct=session.createCriteria(ChangeQuotationReq.class);
                List<ChangeQuotationReq> data =ct.list();
                for(ChangeQuotationReq qt:data){
                    System.out.println(qt.getqId()+" "+qt.getReason()+ ""+qt.getChngType()+" "+qt.getChng());
                }
                     return null;
                 }
        });
    }
        public void showPasswordUpdateReq()
        {
        
        template.execute(new HibernateCallback<Object>() {
            @Override
            public Object doInHibernate(Session session) throws HibernateException, SQLException {
                Criteria ct=session.createCriteria(PasswordUpdateReq.class);
                List<PasswordUpdateReq> data =ct.list();
                for(PasswordUpdateReq passUpdate:data){
                    System.out.println(passUpdate.getUserId()+" "+passUpdate.getOldPass()+" "+passUpdate.getNewPass()+" "+passUpdate.getReason());
                }
                 return null;
                 }
        });               
        }
        
        public void insertSalary(MarketUser ref){
            
            template.execute(new HibernateCallback<Object>() {
                @Override
                public Object doInHibernate(Session session) throws HibernateException, SQLException {
                    session.save(ref);
                    System.out.println("Record Inserted..!!");
                    return null;
                }
            });
        }
        
        public void updateIncentive(String ref){
            
            template.execute(new HibernateCallback<Object>() {
                @Override
                public Object doInHibernate(Session session) throws HibernateException, SQLException {
                MarketUser mUser=(MarketUser)session.get(MarketUser.class,ref);
                if(mUser==null){
                    System.out.println("'Invaild/Id");
                }
                else{
                    System.out.println("1.Incentive");
                    System.out.println("2.Update Basic Salary");
                    System.out.println("3.Exit");
                    System.out.println("Enter Your Choice:");
                    byte choice=sc.nextByte();
                    switch(choice){
                        
                        case 1:
                            int incentive = 0,bSalary = 0,totalSalary = 0;
                            System.out.println("Enter number of Quotation");
                            int nQuot = sc.nextInt();
                           
                            if (nQuot >= 10) {

                                System.out.println("Enter incentive for per Quotation");
                                int incent = sc.nextInt();
                                incentive = nQuot * incent;
                                mUser.setIncentive(incentive);
                                session.update(mUser);
                                bSalary = mUser.getBasicSalary();
                                totalSalary = bSalary + incentive;
                                mUser.setTotalSalary(totalSalary);
                                session.update(mUser);
                                System.out.println("Incentive Updated");
                            }
                            else if(nQuot<10)
                            {
                             
                                bSalary=mUser.getBasicSalary();
                                int deduct=bSalary/30*1/2;
                                mUser.setDeduct(deduct);
                                session.update(mUser);
                                int data=mUser.getTotalSalary();
                                totalSalary=data-deduct;
                                mUser.setTotalSalary(totalSalary);
                                session.update(mUser);
                                System.out.println("Incentive Updated");
                            }                                                                 
                              break;
                             
                        case 2:
                            System.out.println("Enter Amount to update Salary");
                            int uSalary=sc.nextInt();
                            mUser.setBasicSalary(uSalary);
                            session.update(mUser);                          
                            System.out.println("Salary Updated");
                             break;                          
                           
                        case 3:
                            System.exit(0);
                            break;
                    }
                }
                return null;
                }
            });
        }
        
        public void updatePassword(String id,String pass){
            
            template.execute(new HibernateCallback<Object>() {
                @Override
                public Object doInHibernate(Session session) throws HibernateException, SQLException {
                
                    Criteria ct=session.createCriteria(User.class);
                    ct.add(Restrictions.and(Restrictions.eq("userId",id),Restrictions.eq("password",pass)));
                    List<User> data=ct.list();
                    if(data==null){
                        System.out.println("Invalid Id/Password");
                    }
                    else{
                            System.out.println("Enter new password");
                            String nPass=sc.next();
                            System.out.println("Confirm new password");
                            String cPass=sc.next();
                            if(nPass.equalsIgnoreCase(cPass)){
                            User user=(User)session.get(User.class,id);
                            user.setPassword(nPass);
                            session.update(user);
                                System.out.println("Password Updated..."); 
                            }
                    }
                    return null;
                }
            });
        } 
        
        public void updateQuotation(String ref){
            
            template.execute(new HibernateCallback<Object>() {
                @Override
                public Object doInHibernate(Session session) throws HibernateException, SQLException {
             
                    Quotation quot =(Quotation)session.get(Quotation.class,ref);
                   if(quot==null){
                       System.out.println("Invalid Quotation Id");
                   }
                   else{
                       System.out.println("Select Field to Update:");
                       System.out.println("1.Client Name");
                       System.out.println("2.Address");
                       System.out.println("3.Contact");
                       System.out.println("4.Shift Address");
                       System.out.println("5.Quotation Detail");
                       System.out.println("6.Date");
                       System.out.println("7.Exit");
                       System.out.println("Enter your choice:");
                       byte choice=sc.nextByte();
                       switch(choice){
                           
                           case 1:
                               System.out.println("Enter Client name to update:");
                               String uCName=sc.next();
                               quot.setcName(uCName);
                               session.update(quot);
                               System.out.println("Quotation Updated");
                               break;
                           case 2:
                               System.out.println("Enter Address to Update");
                               String uAddress=sc.next();
                               quot.setAddress(uAddress);
                               session.update(quot);
                               System.out.println("Quotation Updated");
                               break;
                           case 3:
                               System.out.println("Enter Contact to Update");
                               String uContact = sc.next();
                               quot.setContact(uContact);
                               session.update(quot);
                               System.out.println("Quotation Updated"); 
                               break;
                           case 4:
                               System.out.println("Enter Shift Address to Update");
                               String uSAddress = sc.next();
                               quot.setShiftAddress(uSAddress);
                               session.update(quot);
                               System.out.println("Quotation Updated"); 
                               break;
                           case 5:
                               System.out.println("Enter Quotation Details to Update");
                               String uDetail= sc.next();
                               quot.setqDetail(uDetail);
                               session.update(quot); 
                               System.out.println("Quotation Updated"); 
                               break;
                           case 6:
                               System.out.println("Enter Date to Update");
                               String uDate = sc.next();
                               quot.setDate(uDate);
                               session.update(quot);
                               System.out.println("Quotation Updated"); 
                               break;
                           case 7:
                               System.exit(0);
                       }
                   }   
                   return "Quotation Updated";
                }
            });
        }
        

}

    
