
package spring.dto;

public class ChangeQuotationReq {
    
    private String qId;
    private String reason;
    private String chngType;
    private String chng;

    public ChangeQuotationReq() {
    }

    public ChangeQuotationReq(String qId, String reason, String chngType, String chng) {
        this.qId = qId;
        this.reason = reason;
        this.chngType = chngType;
        this.chng = chng;
    }

    public String getChng() {
        return chng;
    }

    public void setChng(String chng) {
        this.chng = chng;
    }

    public String getChngType() {
        return chngType;
    }

    public void setChngType(String chngType) {
        this.chngType = chngType;
    }

    public String getqId() {
        return qId;
    }

    public void setqId(String qId) {
        this.qId = qId;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

   
}
