
package spring.dto;

public class User {
    
    private String userId;
    private String password;
    private String post;

    public User() {
    }

    public User(String userId, String password, String post) {
        this.userId = userId;
        this.password = password;
        this.post = post;
    }

    public String getPost() {
        return post;
    }

    public void setPost(String post) {
        this.post = post;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    
   
    }
    

