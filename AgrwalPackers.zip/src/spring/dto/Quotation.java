
package spring.dto;


public class Quotation {
    
    private String qId;
    private String cName;
    private String address;
    private String contact;
    private String shiftAddress;
    private String qDetail;
    private String date;

    public Quotation() {
    }

    public Quotation(String qId, String cName, String address, String contact, String shiftAddress, String qDetail, String date) {
        this.qId = qId;
        this.cName = cName;
        this.address = address;
        this.contact = contact;
        this.shiftAddress = shiftAddress;
        this.qDetail = qDetail;
        this.date = date;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getqId() {
        return qId;
    }

    public void setqId(String qId) {
        this.qId = qId;
    }

    public String getcName() {
        return cName;
    }

    public void setcName(String cName) {
        this.cName = cName;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getShiftAddress() {
        return shiftAddress;
    }

    public void setShiftAddress(String shiftAddress) {
        this.shiftAddress = shiftAddress;
    }

    public String getqDetail() {
        return qDetail;
    }

    public void setqDetail(String qDetail) {
        this.qDetail = qDetail;
    }
    
}
