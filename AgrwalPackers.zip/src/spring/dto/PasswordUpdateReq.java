package spring.dto;


public class PasswordUpdateReq {
    
    private String userId;
    private String oldPass;
    private String newPass;
    private String reason;

    public PasswordUpdateReq() {
    }

    public PasswordUpdateReq(String userId, String oldPass, String newPass, String reason) {
        this.userId = userId;
        this.oldPass = oldPass;
        this.newPass = newPass;
        this.reason = reason;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getOldPass() {
        return oldPass;
    }

    public void setOldPass(String oldPass) {
        this.oldPass = oldPass;
    }

    public String getNewPass() {
        return newPass;
    }

    public void setNewPass(String newPass) {
        this.newPass = newPass;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

   
}