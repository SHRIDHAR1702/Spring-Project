
package spring.dto;


public class MarketUser {
     private String empId;
     private int basicSalary;
     private int incentive;
     private int totalSalary;
     private int deduct;

    public MarketUser() {
    }

    public MarketUser(String empId, int basicSalary, int incentive, int totalSalary, int deduct) {
        this.empId = empId;
        this.basicSalary = basicSalary;
        this.incentive = incentive;
        this.totalSalary = totalSalary;
        this.deduct = deduct;
    }

    

    public String getEmpId() {
        return empId;
    }

    public void setEmpId(String empId) {
        this.empId = empId;
    }

    public int getBasicSalary() {
        return basicSalary;
    }

    public void setBasicSalary(int basicSalary) {
        this.basicSalary = basicSalary;
    }

    public int getIncentive() {
        return incentive;
    }

    public void setIncentive(int incentive) {
        this.incentive = incentive;
    }

    public int getTotalSalary() {
        return totalSalary;
    }

    public void setTotalSalary(int totalSalary) {
        this.totalSalary = totalSalary;
    }

    public int getDeduct() {
        return deduct;
    }

    public void setDeduct(int deduct) {
        this.deduct = deduct;
    }

   
}
